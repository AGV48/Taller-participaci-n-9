from Modelo.Datos_Meteorologicos import DatosMeteorologicos

datos = DatosMeteorologicos("datos.txt")
datos.procesar_datos()
